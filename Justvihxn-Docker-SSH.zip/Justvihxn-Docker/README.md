# Justvihxn Docker VPS Platform

Justvihxn is a Discord-based VPS/container management bot with WebSSH, resource controls, per-instance persistent storage, port forwarding, expiration, billing, and admin tooling.

## What changed

- Docker replaces the previous LXC/LXD runtime.
- Every VPS gets its own named volume: `justvihxn_<container>_data`, mounted at `/data`.
- CPU and RAM are enforced with Docker limits.
- Requested disk size is recorded as Docker labels. **Docker named volumes do not enforce a quota by themselves**; use an XFS project-quota Docker data root or a storage plugin when hard per-volume quotas are required.
- Port forwards are managed through the host's `JUSTVIHXN_DOCKER` iptables chain.
- Each VPS receives password-based root SSH plus an outbound Pinggy TCP tunnel. This works when the Docker host has no public IPv4 or publicly routable IPv6 address.
- The bot, service, commands, website title, database tables, and visible copy use Justvihxn branding.

## Requirements

- A fresh Debian 12 or Ubuntu 22.04/24.04 server
- Root or sudo access
- Recommended: 2 CPU, 4 GB RAM, 20 GB free disk
- A Discord bot token with Message Content intent enabled
- Ports required for WebSSH and your configured forwarding range

## Installation

```bash
unzip Justvihxn-Docker.zip
cd Justvihxn-Docker
sudo bash install.sh
sudo justvihxn config
```

Set at least:

```dotenv
DISCORD_TOKEN=your_discord_bot_token
MAIN_ADMIN_ID=your_discord_user_id
YOUR_SERVER_IP=203.0.113.10
```

Then start and verify:

```bash
sudo justvihxn start
sudo justvihxn status
sudo justvihxn logs
sudo justvihxn doctor
```

Useful commands:

```bash
sudo justvihxn containers
sudo justvihxn volumes
sudo justvihxn restart
```

## VPS SSH

During creation and reinstall, Justvihxn installs and starts OpenSSH in the
container, generates a root password, and opens this outbound tunnel:

```bash
ssh -p 443 -R0:localhost:22 qr+tcp@free.pinggy.io
```

The user receives the assigned Pinggy host, port, root password, and complete
SSH command by Discord DM. The **SSH Tunnel** management button creates a fresh
tunnel when needed. Free tunnel addresses may change after container or host
restarts; Justvihxn attempts to restore them automatically.

The defaults can be changed in `/opt/justvihxn/.env`:

```dotenv
PINGGY_HOST=free.pinggy.io
PINGGY_PORT=443
PINGGY_USER=qr+tcp
PINGGY_LOG_PATH=/root/.pinggy_tunnel.log
```

## Firewall

If UFW is enabled, allow the WebSSH port and forwarding range (adjust as needed):

```bash
sudo ufw allow 5000/tcp
sudo ufw allow 20000:50000/tcp
sudo ufw allow 20000:50000/udp
```

## Persistent storage

User data should be kept in `/data` inside each VPS container. Deleting a VPS through Justvihxn removes both its container and dedicated volume. Normal container restarts/recreates preserve the volume.

Back up a volume:

```bash
docker run --rm -v justvihxn_CONTAINER_data:/data -v "$PWD":/backup ubuntu:24.04 \
  tar czf /backup/CONTAINER-data.tgz -C /data .
```

## Hard disk quotas (optional)

The `PUBLIC_VPS_MAX_DISK`/plan disk value is retained as metadata. To enforce hard quotas, configure Docker's `overlay2.size` support on an XFS filesystem mounted with `pquota`, or use a quota-aware volume driver. Test this on a staging host before production.

## Remote nodes

The included installer configures the local Docker node. Existing remote-node entries must point to an API agent that executes the supplied Docker shell command and returns `returncode`, `stdout`, and `stderr`. Install Docker and iptables on every node and protect the node API with its key and a firewall.

## Security notes

Managed containers receive elevated capabilities (`NET_ADMIN`, `SYS_ADMIN`, `/dev/fuse`) for compatibility with the existing VPS feature set. This is not suitable for untrusted public multi-tenancy without additional isolation. For hostile tenants, use rootless Docker, gVisor/Kata Containers, or full KVM VMs and remove unnecessary capabilities.
