#!/usr/bin/env python3
"""Freaky Cloud Docker backend.

Translates the panel's legacy container command grammar into safe Docker CLI
operations. Keeping the grammar stable avoids breaking existing API clients
while the runtime is fully Docker-based.
"""
from __future__ import annotations

import json
import os
import re
import shlex
import shutil
import subprocess
import time
from pathlib import Path
from typing import Any, Dict, List

DOCKER_BIN = os.getenv("DOCKER_BIN", "docker")
STATE_DIR = Path(os.getenv("FREAKY_STATE_DIR", "/var/lib/freaky-cloud"))
NETWORK = os.getenv("DOCKER_NETWORK", "bridge")


def _run(args: List[str], timeout: int = 120, check: bool = False) -> Dict[str, Any]:
    started = time.time()
    proc = subprocess.run(args, capture_output=True, text=True, timeout=timeout)
    result = {
        "success": proc.returncode == 0,
        "returncode": proc.returncode,
        "stdout": proc.stdout.strip(),
        "stderr": proc.stderr.strip(),
        "command": shlex.join(args),
        "execution_time": round(time.time() - started, 3),
    }
    if check and proc.returncode:
        raise RuntimeError(result["stderr"] or f"Command failed: {result['command']}")
    return result


def docker_available() -> bool:
    return shutil.which(DOCKER_BIN) is not None


def docker_version() -> str:
    if not docker_available():
        return "Unavailable"
    result = _run([DOCKER_BIN, "version", "--format", "{{.Server.Version}}"], 10)
    return result["stdout"] or "Unknown"


def normalize_image(image: str) -> str:
    image = image.strip()
    mappings = {
        "ubuntu:20.04": "ubuntu:20.04",
        "ubuntu:22.04": "ubuntu:22.04",
        "ubuntu:24.04": "ubuntu:24.04",
        "images:debian/10": "debian:10",
        "images:debian/11": "debian:11",
        "images:debian/12": "debian:12",
        "images:debian/13": "debian:13",
    }
    if image in mappings:
        return mappings[image]
    if image.startswith("images:"):
        return image[7:].replace("/", ":", 1)
    return image


def list_containers() -> List[str]:
    result = _run([DOCKER_BIN, "ps", "-a", "--format", "{{.Names}}"], 15)
    return [x for x in result["stdout"].splitlines() if x.strip()] if result["success"] else []


def container_exists(name: str) -> bool:
    return _run([DOCKER_BIN, "inspect", name], 10)["success"]


def container_status(name: str) -> str:
    result = _run([DOCKER_BIN, "inspect", "--format", "{{.State.Status}}", name], 10)
    if not result["success"]:
        return "not found"
    return {"exited": "stopped", "created": "stopped", "paused": "frozen"}.get(result["stdout"], result["stdout"])


def container_inspect(name: str) -> Dict[str, Any]:
    result = _run([DOCKER_BIN, "inspect", name], 15, check=True)
    return json.loads(result["stdout"])[0]


def container_stats(name: str) -> Dict[str, Any]:
    status = container_status(name)
    base = {"status": status, "cpu": 0.0, "ram": {"used": 0, "total": 0, "percent": 0.0}, "disk": "N/A", "uptime": "N/A"}
    if status != "running":
        return base
    result = _run([DOCKER_BIN, "stats", "--no-stream", "--format", "{{json .}}", name], 15)
    if result["success"] and result["stdout"]:
        data = json.loads(result["stdout"].splitlines()[0])
        base["cpu"] = float(str(data.get("CPUPerc", "0")).replace("%", "") or 0)
        mem = str(data.get("MemUsage", "0 / 0"))
        base["ram"] = {"used_human": mem.split("/")[0].strip(), "total_human": mem.split("/")[-1].strip(),
                       "percent": float(str(data.get("MemPerc", "0")).replace("%", "") or 0)}
        base["disk"] = str(data.get("BlockIO", "N/A"))
    info = container_inspect(name)
    started = info.get("State", {}).get("StartedAt", "")
    base["uptime"] = started or "N/A"
    return base


def _iptables(action: str, protocol: str, host_port: str, container_ip: str, target_port: str) -> Dict[str, Any]:
    # Docker publishes added after creation through explicit DNAT rules.
    spec = ["-p", protocol, "--dport", str(host_port), "-j", "DNAT", "--to-destination", f"{container_ip}:{target_port}"]
    cmd = ["iptables", "-t", "nat", action, "DOCKER"] + spec
    return _run(cmd, 15)


def _port_rule(command: List[str], add: bool) -> Dict[str, Any]:
    # config device add NAME id proxy listen=tcp:0.0.0.0:HOST connect=tcp:127.0.0.1:TARGET
    name = command[3]
    text = " ".join(command)
    listen = re.search(r"listen=(tcp|udp):[^:]+:(\d+)", text)
    connect = re.search(r"connect=(tcp|udp):[^:]+:(\d+)", text)
    if not (listen and connect):
        return {"success": True, "returncode": 0, "stdout": "No Docker port rule required", "stderr": ""}
    info = container_inspect(name)
    networks = info.get("NetworkSettings", {}).get("Networks", {})
    ip = next((v.get("IPAddress") for v in networks.values() if v.get("IPAddress")), "")
    if not ip:
        return {"success": False, "returncode": 1, "stdout": "", "stderr": "Container must be running before adding a port forward"}
    return _iptables("-A" if add else "-D", listen.group(1), listen.group(2), ip, connect.group(2))


def execute(command: str, timeout: int = 120) -> Dict[str, Any]:
    """Execute a legacy panel command through Docker, never through a shell."""
    tokens = shlex.split(command)
    if tokens and tokens[0] == "docker":
        tokens = tokens[1:]
    if not tokens:
        return {"success": False, "returncode": 2, "stdout": "", "stderr": "Empty command"}
    op = tokens[0]

    if op in {"version", "--version"}:
        return _run([DOCKER_BIN, "version", "--format", "Docker {{.Server.Version}}"], timeout)
    if op == "list":
        return _run([DOCKER_BIN, "ps", "-a", "--format", "json"], timeout)
    if op == "info" and len(tokens) > 1:
        name = tokens[1]
        status = container_status(name)
        if status == "not found":
            return {"success": False, "returncode": 1, "stdout": "", "stderr": f"Container {name} not found"}
        info = container_inspect(name)
        output = f"Name: {name}\nStatus: {status.upper()}\nImage: {info.get('Config', {}).get('Image', 'Unknown')}"
        return {"success": True, "returncode": 0, "stdout": output, "stderr": ""}
    if op == "init" and len(tokens) >= 3:
        image, name = normalize_image(tokens[1]), tokens[2]
        return _run([DOCKER_BIN, "create", "--name", name, "--hostname", name, "--privileged",
                     "--restart", "unless-stopped", "--network", NETWORK,
                     "--label", "com.freakycloud.managed=true", image, "sleep", "infinity"], timeout)
    if op in {"start", "restart", "pause", "unpause"} and len(tokens) > 1:
        docker_op = {"pause": "pause", "unpause": "unpause"}.get(op, op)
        return _run([DOCKER_BIN, docker_op, tokens[1]], timeout)
    if op == "freeze" and len(tokens) > 1:
        return _run([DOCKER_BIN, "pause", tokens[1]], timeout)
    if op == "unfreeze" and len(tokens) > 1:
        return _run([DOCKER_BIN, "unpause", tokens[1]], timeout)
    if op == "stop" and len(tokens) > 1:
        args = [DOCKER_BIN, "kill" if "--force" in tokens else "stop", tokens[1]]
        return _run(args, timeout)
    if op == "delete" and len(tokens) > 1:
        target = tokens[1]
        if "/" in target:  # snapshot image: container/snapshot
            container, snapshot = target.split("/", 1)
            return _run([DOCKER_BIN, "image", "rm", f"freakycloud/{container}:{snapshot}"], timeout)
        return _run([DOCKER_BIN, "rm"] + (["-f"] if "--force" in tokens else []) + [target], timeout)
    if op == "exec" and len(tokens) > 1:
        if tokens[1] == "--":
            return _run(tokens[2:], timeout)
        name = tokens[1]
        rest = tokens[3:] if len(tokens) > 2 and tokens[2] == "--" else tokens[2:]
        return _run([DOCKER_BIN, "exec", name] + rest, timeout)
    if op == "config" and len(tokens) > 3:
        if tokens[1:3] == ["device", "add"] and "proxy" in tokens:
            return _port_rule(tokens, True)
        if tokens[1:3] == ["device", "remove"]:
            # Infer protocol/ports from the device id: tcp_proxy_12345.
            name, device = tokens[3], tokens[4] if len(tokens) > 4 else ""
            match = re.match(r"(tcp|udp)_proxy_(\d+)", device)
            if not match:
                return {"success": True, "returncode": 0, "stdout": "", "stderr": ""}
            # Delete any matching DOCKER-chain rule by rule number/spec is environment-specific.
            result = _run(["iptables", "-t", "nat", "-S", "DOCKER"], 15)
            for line in result["stdout"].splitlines():
                if f"-p {match.group(1)}" in line and f"--dport {match.group(2)}" in line:
                    return _run(["iptables", "-t", "nat"] + shlex.split(line.replace("-A ", "-D ", 1)), 15)
            return {"success": True, "returncode": 0, "stdout": "Rule already absent", "stderr": ""}
        if tokens[1] == "set":
            name, key = tokens[2], tokens[3]
            value = tokens[4] if len(tokens) > 4 else ""
            if key == "limits.memory":
                return _run([DOCKER_BIN, "update", "--memory", value, "--memory-swap", value, name], timeout)
            if key == "limits.cpu":
                return _run([DOCKER_BIN, "update", "--cpus", value, name], timeout)
            # Privilege/nesting/capabilities are set at docker create time.
            return {"success": True, "returncode": 0, "stdout": f"Docker setting managed at create time: {key}", "stderr": ""}
        if tokens[1:3] == ["device", "set"]:
            # Overlay2 writable-layer quotas require XFS pquota and daemon setup.
            return {"success": True, "returncode": 0, "stdout": "Disk quota recorded by Freaky Cloud; configure overlay2 pquota to enforce it", "stderr": ""}
    if op == "snapshot" and len(tokens) >= 3:
        return _run([DOCKER_BIN, "commit", tokens[1], f"freakycloud/{tokens[1]}:{tokens[2]}"], timeout)
    if op == "restore" and len(tokens) >= 3:
        return {"success": False, "returncode": 2, "stdout": "", "stderr": "Docker snapshot restore requires VPS reinstall from the committed image"}
    if op == "storage" and len(tokens) > 1 and tokens[1] == "list":
        return _run([DOCKER_BIN, "info", "--format", "Driver: {{.Driver}}\nDocker Root: {{.DockerRootDir}}"], timeout)
    if op == "network" and len(tokens) > 1 and tokens[1] == "list":
        return _run([DOCKER_BIN, "network", "ls"], timeout)
    return {"success": False, "returncode": 2, "stdout": "", "stderr": f"Unsupported Docker operation: {command}"}
