# Migrating an Existing Installation

This release changes the managed runtime from LXC/LXD to Docker. It does **not** convert existing running LXC containers in place.

## Panel data

The bundled SQLite database is retained as `freakycloud.db`. The installer copies it to `data/freakycloud.db`, preserving users, VPS records, nodes, quotas, and settings. Branding settings have been updated to Freaky Cloud.

## Existing workloads

For each existing LXC workload:

1. Back up application data and databases from the old container.
2. Provision a new Docker VPS in Freaky Cloud with the matching Ubuntu/Debian release.
3. Reinstall the application and restore its data.
4. Recreate port forwards in the panel.
5. Verify DNS, TLS, backups, and application health before retiring the LXC instance.

Do not point the converted panel at old LXC nodes. Install the Freaky Cloud Docker node agent on each host and add it as a new node.

## Important differences

- Docker containers share the host kernel; they are not KVM virtual machines.
- Dedicated public IPs require host routing or a Docker macvlan/ipvlan network.
- Disk quota enforcement requires overlay2 on XFS with project quotas.
- Existing LXC snapshots cannot be restored by Docker.
