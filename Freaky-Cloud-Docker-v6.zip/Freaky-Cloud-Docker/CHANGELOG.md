# Freaky Cloud 6.0 — Docker Conversion

- Replaced LXC/LXD execution with a Docker CLI backend.
- Rebuilt the remote node agent for Docker.
- Added Docker lifecycle operations, CPU/RAM limits, stats, exec, pause, snapshots, and dynamic port DNAT.
- Added Dockerfiles, Docker Compose, installer, example environments, and migration documentation.
- Rebranded panel copy, defaults, stored settings, logo, favicon, colors, logs, database, and container naming.
- Hardened SSH bootstrap by generating a deployment credential instead of using `root:root`.
- Preserved existing Flask routes and API behavior where possible.
