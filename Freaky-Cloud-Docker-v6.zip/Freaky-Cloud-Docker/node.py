#!/usr/bin/env python3
"""Freaky Cloud Docker Node Agent."""
import argparse
import logging
import os
import platform
import secrets
import signal
import sys
from functools import wraps

import psutil
from flask import Flask, jsonify, request
from flask_cors import CORS
from dotenv import load_dotenv

from docker_backend import (container_exists, container_stats, container_status,
                            docker_available, docker_version, execute,
                            list_containers)

load_dotenv()
app = Flask(__name__)
CORS(app)
API_KEY = os.getenv("API_KEY", "")
logging.basicConfig(level=getattr(logging, os.getenv("LOG_LEVEL", "INFO").upper(), logging.INFO),
                    format="%(asctime)s - FreakyNode - %(levelname)s - %(message)s",
                    handlers=[logging.StreamHandler(), logging.FileHandler(os.getenv("LOG_FILE", "freaky-node.log"))])
logger = logging.getLogger("freaky-node")


def require_api_key(fn):
    @wraps(fn)
    def wrapped(*args, **kwargs):
        supplied = request.headers.get("X-API-Key") or request.args.get("api_key")
        if not API_KEY or not supplied or not secrets.compare_digest(supplied, API_KEY):
            return jsonify({"success": False, "error": "Invalid or missing API key"}), 401
        return fn(*args, **kwargs)
    return wrapped


def host_stats():
    disk = psutil.disk_usage("/")
    mem = psutil.virtual_memory()
    return {"cpu": psutil.cpu_percent(interval=0.15),
            "ram": {"used": mem.used, "total": mem.total, "percent": mem.percent},
            "disk": {"used": disk.used, "total": disk.total, "percent": disk.percent},
            "uptime_seconds": int(__import__("time").time() - psutil.boot_time())}


@app.get("/api/health")
def health():
    return jsonify({"success": True, "service": "Freaky Cloud Docker Node", "docker": docker_available(), "version": docker_version()})


@app.get("/api/ping")
@require_api_key
def ping():
    return jsonify({"success": True, "message": "pong", "runtime": "docker"})


@app.post("/api/test-connection")
@require_api_key
def test_connection():
    return jsonify({"success": docker_available(), "runtime": "docker", "docker_version": docker_version(), "host": host_stats()})


@app.post("/api/execute")
@require_api_key
def api_execute():
    data = request.get_json(silent=True) or {}
    result = execute(data.get("command", ""), int(data.get("timeout", 120)))
    return jsonify(result), 200 if result["success"] else 500


@app.get("/api/host/stats")
@require_api_key
def api_host_stats():
    return jsonify({"success": True, **host_stats()})


@app.get("/api/container/list")
@require_api_key
def api_container_list():
    containers = list_containers()
    return jsonify({"success": True, "containers": containers, "count": len(containers)})


@app.post("/api/container/stats")
@require_api_key
def api_container_stats():
    name = (request.get_json(silent=True) or {}).get("container", "")
    return jsonify({"success": True, **container_stats(name)})


def action(op):
    data = request.get_json(silent=True) or {}
    name = data.get("container", "")
    result = execute(f"{op} {shlex_quote(name)}", int(data.get("timeout", 60)))
    return jsonify(result), 200 if result["success"] else 500


def shlex_quote(value):
    import shlex
    return shlex.quote(value)


@app.post("/api/container/start")
@require_api_key
def start(): return action("start")

@app.post("/api/container/stop")
@require_api_key
def stop(): return action("stop")

@app.post("/api/container/restart")
@require_api_key
def restart(): return action("restart")

@app.post("/api/container/delete")
@require_api_key
def delete():
    data = request.get_json(silent=True) or {}
    suffix = " --force" if data.get("force", False) else ""
    result = execute(f"delete {shlex_quote(data.get('container', ''))}{suffix}")
    return jsonify(result), 200 if result["success"] else 500

@app.post("/api/container/exec")
@require_api_key
def exec_in_container():
    data = request.get_json(silent=True) or {}
    result = execute(f"exec {shlex_quote(data.get('container', ''))} -- {data.get('command', '')}", int(data.get("timeout", 60)))
    return jsonify(result), 200 if result["success"] else 500

@app.get("/api/info")
@require_api_key
def info():
    return jsonify({"success": True, "name": "Freaky Cloud Node", "runtime": "Docker", "runtime_version": docker_version(),
                    "hostname": platform.node(), "platform": platform.platform(), "containers": len(list_containers()), "host": host_stats()})

@app.get("/api/system/check")
@require_api_key
def system_check():
    ok = docker_available()
    return jsonify({"success": ok, "node_ready": ok, "checks": {"docker_available": ok},
                    "errors": [] if ok else ["Docker command not found"]})

@app.post("/api/validate")
@require_api_key
def validate(): return system_check()

@app.post("/api/container/snapshot")
@require_api_key
def snapshot():
    data = request.get_json(silent=True) or {}
    name, snap, op = data.get("container", ""), data.get("snapshot_name", "snapshot"), data.get("action", "create")
    result = execute(f"snapshot {shlex_quote(name)} {shlex_quote(snap)}" if op == "create" else f"delete {shlex_quote(name + '/' + snap)} --force")
    return jsonify(result), 200 if result["success"] else 500


def main():
    parser = argparse.ArgumentParser(description="Freaky Cloud Docker Node Agent")
    parser.add_argument("--host", default=os.getenv("HOST", "0.0.0.0"))
    parser.add_argument("--port", type=int, default=int(os.getenv("PORT", "5001")))
    parser.add_argument("--debug", action="store_true")
    args = parser.parse_args()
    if not API_KEY:
        logger.error("API_KEY is required")
        sys.exit(1)
    signal.signal(signal.SIGTERM, lambda *_: sys.exit(0))
    app.run(host=args.host, port=args.port, debug=args.debug, threaded=True)

if __name__ == "__main__":
    main()
