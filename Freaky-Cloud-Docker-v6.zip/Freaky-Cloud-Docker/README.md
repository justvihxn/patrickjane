# Freaky Cloud — Docker VPS Hosting Panel

Freaky Cloud is the Docker-native conversion of the original container panel. It manages isolated Docker VPS-style containers on a local host or remote Docker nodes.

## Requirements

- Ubuntu/Debian VPS with root access
- Docker Engine and Docker Compose v2
- Ports `5000/tcp` (panel) and `5001/tcp` (remote node agent, if used)
- `iptables` support for dynamic port forwarding

## Quick install

```bash
unzip Freaky-Cloud-Docker.zip
cd svm_panel
sudo ./install.sh
```

Open `http://YOUR_SERVER_IP:5000`. Before exposing it publicly, edit `.env`, change `MAIN_ADMIN_PASSWORD`, configure a reverse proxy with HTTPS, and run `docker compose restart`.

## Remote Docker node

1. Copy this project to the remote VPS.
2. Copy `node.env.example` to `node.env`, set a unique `API_KEY`, and restrict port 5001 to the panel IP.
3. Run `docker compose --profile node up -d --build freaky-node`.
4. Add the node in the Freaky Cloud admin area using `http://NODE_IP:5001` and the same API key.

## Runtime notes

- Supported images: Ubuntu 20.04/22.04/24.04 and Debian 10–13.
- CPU and RAM limits are enforced with `docker update`.
- Containers run privileged to preserve the original VPS-like workflow and nested-service compatibility. Use only trusted customers/workloads; privileged Docker containers are not a hardened multi-tenant security boundary.
- Dynamic ports use DNAT rules in Docker's `DOCKER` iptables chain.
- Disk sizes are recorded in the panel. Enforcing writable-layer quotas requires Docker `overlay2` on XFS with project quotas (`pquota`); configure this on every node.
- The service IP field is retained as account metadata. For dedicated public IPs, configure routing/macvlan on the host; Docker-managed `eth0` is not modified inside the container.
- Docker snapshots use `docker commit` images under `freakycloud/<container>:<snapshot>`.

## Production checklist

- Put the panel behind Caddy, Nginx, or Traefik with TLS.
- Firewall ports 5000/5001; expose only what is required.
- Use unique node API keys and rotate them periodically.
- Store the generated `DEFAULT_ROOT_PASSWORD` securely and rotate VPS credentials after provisioning.
- Back up `data/freakycloud.db` and `/var/lib/freaky-cloud`.
- Do not expose the Docker socket over TCP.
