#!/usr/bin/env bash
set -euo pipefail
if [[ $EUID -ne 0 ]]; then echo "Run as root: sudo ./install.sh"; exit 1; fi
command -v docker >/dev/null || { curl -fsSL https://get.docker.com | sh; }
docker compose version >/dev/null 2>&1 || { echo "Docker Compose v2 is required."; exit 1; }
[[ -f .env ]] || cp .env.example .env
[[ -f node.env ]] || cp node.env.example node.env
mkdir -p data /var/lib/freaky-cloud
if [[ -f freakycloud.db && ! -f data/freakycloud.db ]]; then cp freakycloud.db data/freakycloud.db; fi
SECRET=$(openssl rand -hex 32)
APIKEY=$(openssl rand -hex 32)
VPSPASS=$(openssl rand -base64 24 | tr -d "\n")
sed -i "0,/replace-with-openssl-rand-hex-32/s//$SECRET/" .env
sed -i "s/change-this-vps-password/$VPSPASS/" .env
sed -i "s/replace-with-openssl-rand-hex-32/$APIKEY/" node.env
chmod 600 .env node.env
docker compose up -d --build
echo "Freaky Cloud is running on port 5000. Change MAIN_ADMIN_PASSWORD in .env, then restart."
