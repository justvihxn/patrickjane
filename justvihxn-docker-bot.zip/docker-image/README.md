Build the provider image from the project root:

```bash
docker build -t justvihxn/ubuntu-ssh:24.04 docker-image/
```

The image accepts `SSH_PUBLIC_KEY` and `SSH_USER`, disables password/root login, and starts OpenSSH in the foreground.
