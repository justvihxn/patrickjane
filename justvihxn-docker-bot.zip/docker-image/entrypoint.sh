#!/usr/bin/env bash
set -euo pipefail
user="${SSH_USER:-justvihxn}"
if ! id "$user" >/dev/null 2>&1; then
  useradd --create-home --shell /bin/bash "$user"
fi
install -d -m 0700 -o "$user" -g "$user" "/home/$user/.ssh"
printf '%s\n' "${SSH_PUBLIC_KEY:?SSH_PUBLIC_KEY is required}" > "/home/$user/.ssh/authorized_keys"
chown "$user:$user" "/home/$user/.ssh/authorized_keys"
chmod 0600 "/home/$user/.ssh/authorized_keys"
mkdir -p "/home/$user/data"
chown "$user:$user" "/home/$user/data"
passwd -l root >/dev/null 2>&1 || true
printf '%s\n' 'PasswordAuthentication no' 'PermitRootLogin no' 'PubkeyAuthentication yes' 'AllowTcpForwarding no' 'X11Forwarding no' > /etc/ssh/sshd_config.d/justvihxn.conf
exec /usr/sbin/sshd -D -e
