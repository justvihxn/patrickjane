# Justvihxn Docker Provider Bot

A Justvihxn-branded Discord provider bot for **IPv6-only Docker VPS-style containers**. It preserves the Cryzon-style workflow shown in the reference screenshots—plans, invite eligibility, deployment, lifecycle controls, renewals, credits, admin tools, logs, and consistent embeds—using an original implementation and Justvihxn branding.

## Design system

- **Pattern:** slash command → permission/eligibility validation → progress → result.
- **Style:** trust-first dark infrastructure interface aligned with Discord.
- **Colors:** cyan `#22D3EE`, green `#22C55E`, amber `#F59E0B`, red `#EF4444`.
- **Typography:** Discord native; monospace for addresses, IDs, and commands.
- **Safety:** SSH keys only, ephemeral secrets, confirmation for deletion/rebuild, resource limits, and no IPv4 address assignment.

## Features and commands

### Provider lifecycle

`/buy`, `/deploy`, `/start`, `/stop`, `/status`, `/listvpses`, `/rebuild`, `/vps_delete`, `/suspendvps`, `/unsuspendvps`, `/sharevps`, `/vpscheck_owner`, `/regen_ssh`, `/usercleanvps`, `/clearnode`.

### Invites and tickets

`/invites`, `/invitesadd`, `/invitesremove`, `/invitereseteveryone`, `/ticketcheck`, `/ticketdeploy`, `/ticketauto`, `/claimmessage` plus join, leave, fake-account, and rejoin logging.

### Plans, renewals, and credits

`/planadd`, `/planmessageadd`, `/renew`, `/renewadd`, `/renewvps`, `/redeemcreate`, `/m`, `/message`, `/messageadd`, `/messageremove`, `/messagereset`, `/giveaway`.

### Administration

`/admin_add`, `/admin_remove`, `/admin_list`, `/admins`, `/nodes`, `/list`, `/help`, `/ping`.

## Provider behavior

- Creates one Docker container per VPS record.
- Applies CPU, RAM, PID, capability, and no-new-privileges limits.
- Assigns a deterministic address from a dedicated IPv6 prefix.
- Creates the Docker network with `--ipv6 --ipv4=false`; containers receive no Docker IPv4 address.
- Uses a named volume for `/home/justvihxn/data`.
- Authenticates SSH with a user-supplied public key; password and root login are disabled.
- Rebuilds preserve the named data volume. Permanent deletion removes it.
- Starts with provider execution disabled until configuration is reviewed.

> Containers share the host kernel and are not equivalent to hardware virtual machines. Do not sell them as KVM/QEMU VPS instances. Use strong host isolation, firewalling, monitoring, backups, and clear customer disclosure.

## Requirements

- Linux provider host
- Docker Engine **27+** (required for `docker network create --ipv4=false`)
- A routed IPv6 `/64` or other sufficiently large prefix
- Python 3.11+
- Discord application with Server Members Intent

## Setup

1. Create a Discord bot and invite it with the `bot` and `applications.commands` scopes.
2. Copy configuration:

   ```bash
   cp .env.example .env
   cp config.example.yml config.yml
   ```

3. Set `DISCORD_TOKEN`, `OWNER_IDS`, the routed IPv6 prefix, gateway, and desired plans.
4. Build the SSH container image:

   ```bash
   docker build -t justvihxn/ubuntu-ssh:24.04 docker-image/
   ```

5. Install Python dependencies:

   ```bash
   python3 -m venv .venv
   . .venv/bin/activate
   pip install -r requirements.txt
   ```

6. Start once with `docker.enabled: false`:

   ```bash
   python bot.py
   ```

7. Verify slash commands and permissions. Then set `docker.enabled: true` and test with a non-production account.

Alternatively, after installing Docker Engine 27+, run `sudo ./install.sh` and follow its final instructions.

## IPv6 networking

The bot creates the configured network with:

```bash
docker network create --ipv6 --ipv4=false \
  --subnet fd42:6a73:7476:100::/64 \
  --gateway fd42:6a73:7476:100::1 \
  justvihxn-v6
```

The default sample uses a ULA prefix for safe configuration testing. Replace it with a properly routed production prefix before expecting internet reachability. Configure IPv6 forwarding, routing, neighbor discovery/proxying where required, and nftables rules on the host. Do not add IPv4 port publishing if strict IPv6-only service is required.

## Security notes

- Membership in the host `docker` group is effectively root-level access. Run the bot on a dedicated provider host and protect its Discord token and owner IDs.
- The included container intentionally exposes only SSH inside its Docker network. It does not publish an IPv4 host port.
- Disk size is recorded as plan metadata; ordinary local Docker volumes do not enforce per-volume quotas. Configure XFS project quotas, a quota-capable volume driver, or ZFS datasets before production billing.
- Add image signature/checksum verification, expiry enforcement, backups, abuse controls, rate limiting, audit logs, monitoring, and automated patching before serving untrusted users.
- Never put the Discord token in source code or screenshots.
