from justvihxn.bot import run
if __name__ == "__main__": run()
