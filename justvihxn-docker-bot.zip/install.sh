#!/usr/bin/env bash
set -euo pipefail
[[ $EUID -eq 0 ]] || { echo "Run as root"; exit 1; }
command -v docker >/dev/null || { echo "Install Docker Engine 27+ first: https://docs.docker.com/engine/install/"; exit 1; }
docker network create --help | grep -q -- '--ipv4' || { echo "Docker Engine 27+ with --ipv4=false network support is required"; exit 1; }
apt-get update && apt-get install -y python3-venv
id -u justvihxn-bot >/dev/null 2>&1 || useradd --system --create-home justvihxn-bot
usermod -aG docker justvihxn-bot
install -d -o justvihxn-bot -g justvihxn-bot /opt/justvihxn-docker-bot
cp -a . /opt/justvihxn-docker-bot/
python3 -m venv /opt/justvihxn-docker-bot/.venv
/opt/justvihxn-docker-bot/.venv/bin/pip install -r /opt/justvihxn-docker-bot/requirements.txt
docker build -t justvihxn/ubuntu-ssh:24.04 /opt/justvihxn-docker-bot/docker-image
cp deploy/justvihxn-docker-bot.service /etc/systemd/system/
systemctl daemon-reload
echo "Edit /opt/justvihxn-docker-bot/.env and config.yml, then run: systemctl enable --now justvihxn-docker-bot"
