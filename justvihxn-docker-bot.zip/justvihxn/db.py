from __future__ import annotations
import json
from pathlib import Path
import aiosqlite

SCHEMA = """
PRAGMA journal_mode=WAL;
CREATE TABLE IF NOT EXISTS admins(user_id INTEGER PRIMARY KEY, added_at TEXT DEFAULT CURRENT_TIMESTAMP);
CREATE TABLE IF NOT EXISTS users(user_id INTEGER PRIMARY KEY, credits INTEGER NOT NULL DEFAULT 0, custom_invites INTEGER NOT NULL DEFAULT 0);
CREATE TABLE IF NOT EXISTS invites(guild_id INTEGER, user_id INTEGER, joins INTEGER DEFAULT 0, leaves INTEGER DEFAULT 0, fake INTEGER DEFAULT 0, rejoins INTEGER DEFAULT 0, inviter_id INTEGER, PRIMARY KEY(guild_id,user_id));
CREATE TABLE IF NOT EXISTS member_history(guild_id INTEGER, user_id INTEGER, inviter_id INTEGER, joined_at TEXT DEFAULT CURRENT_TIMESTAMP, left_at TEXT, PRIMARY KEY(guild_id,user_id));
CREATE TABLE IF NOT EXISTS vms(id TEXT PRIMARY KEY, owner_id INTEGER NOT NULL, name TEXT UNIQUE NOT NULL, plan TEXT NOT NULL, ipv6 TEXT UNIQUE, state TEXT NOT NULL DEFAULT 'defined', expires_at TEXT, shared_with TEXT DEFAULT '[]', created_at TEXT DEFAULT CURRENT_TIMESTAMP);
CREATE TABLE IF NOT EXISTS settings(key TEXT PRIMARY KEY, value TEXT NOT NULL);
CREATE TABLE IF NOT EXISTS redemptions(code TEXT PRIMARY KEY, days INTEGER NOT NULL, max_uses INTEGER NOT NULL DEFAULT 1, uses INTEGER NOT NULL DEFAULT 0, created_by INTEGER NOT NULL, created_at TEXT DEFAULT CURRENT_TIMESTAMP);
"""

class Database:
    def __init__(self, path: Path): self.path = path
    async def init(self):
        self.path.parent.mkdir(parents=True, exist_ok=True)
        async with aiosqlite.connect(self.path) as db: await db.executescript(SCHEMA); await db.commit()
    async def execute(self, sql, params=()):
        async with aiosqlite.connect(self.path) as db:
            cur=await db.execute(sql, params); await db.commit(); return cur.rowcount
    async def fetchone(self, sql, params=()):
        async with aiosqlite.connect(self.path) as db:
            db.row_factory=aiosqlite.Row; cur=await db.execute(sql, params); return await cur.fetchone()
    async def fetchall(self, sql, params=()):
        async with aiosqlite.connect(self.path) as db:
            db.row_factory=aiosqlite.Row; cur=await db.execute(sql, params); return await cur.fetchall()
    async def ensure_user(self, uid): await self.execute("INSERT OR IGNORE INTO users(user_id) VALUES(?)", (uid,))
    async def is_admin(self, uid, owners):
        if uid in owners: return True
        return bool(await self.fetchone("SELECT 1 FROM admins WHERE user_id=?", (uid,)))
    async def user_vms(self, uid): return await self.fetchall("SELECT * FROM vms WHERE owner_id=? ORDER BY created_at", (uid,))
    async def find_vm(self, name): return await self.fetchone("SELECT * FROM vms WHERE name=?", (name,))
