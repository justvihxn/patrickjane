from __future__ import annotations
import discord
from discord import app_commands

def bot_admin():
    async def predicate(interaction: discord.Interaction):
        ok=await interaction.client.db.is_admin(interaction.user.id, interaction.client.settings.owner_ids)
        if not ok: raise app_commands.CheckFailure("Justvihxn administrator access required")
        return True
    return app_commands.check(predicate)
