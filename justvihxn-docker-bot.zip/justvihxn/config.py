from __future__ import annotations
import os
from dataclasses import dataclass
from pathlib import Path
from typing import Any
import yaml
from dotenv import load_dotenv

load_dotenv()

@dataclass(frozen=True)
class Settings:
    token: str
    guild_id: int | None
    owner_ids: frozenset[int]
    database_path: Path
    config_path: Path
    raw: dict[str, Any]

    @property
    def brand(self) -> dict[str, Any]: return self.raw["brand"]
    @property
    def docker(self) -> dict[str, Any]: return self.raw["docker"]
    @property
    def invites(self) -> dict[str, Any]: return self.raw.get("invites", {})
    @property
    def plans(self) -> dict[str, Any]: return self.raw.get("plans", {})


def load_settings() -> Settings:
    path = Path(os.getenv("CONFIG_PATH", "config.yml"))
    if not path.exists():
        raise RuntimeError("config.yml missing; copy config.example.yml and edit it")
    raw = yaml.safe_load(path.read_text())
    token = os.getenv("DISCORD_TOKEN", "").strip()
    if not token: raise RuntimeError("DISCORD_TOKEN is required")
    guild = os.getenv("DISCORD_GUILD_ID", "").strip()
    owners = frozenset(int(x) for x in os.getenv("OWNER_IDS", "").split(",") if x.strip())
    return Settings(token, int(guild) if guild else None, owners,
                    Path(os.getenv("DATABASE_PATH", "data/justvihxn.db")), path, raw)
