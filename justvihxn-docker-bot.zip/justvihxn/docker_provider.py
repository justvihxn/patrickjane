from __future__ import annotations
import asyncio
import hashlib
import ipaddress
import re

NAME_RE = re.compile(r"^[a-z0-9][a-z0-9-]{2,31}$")

class DockerError(RuntimeError):
    pass

class DockerProvider:
    """Safe async wrapper around Docker CLI for IPv6-only VPS-like containers."""
    def __init__(self, cfg: dict):
        self.cfg = cfg
        self.enabled = bool(cfg.get("enabled", False))
        self.timeout = int(cfg.get("command_timeout_seconds", 120))
        self.network = cfg.get("network", "justvihxn-v6")
        self.prefix = ipaddress.IPv6Network(cfg["ipv6_prefix"])

    async def _run(self, *args: str, allow_failure: bool = False) -> str:
        if not self.enabled:
            raise DockerError("Docker operations are disabled in config.yml")
        try:
            proc = await asyncio.create_subprocess_exec(
                "docker", *args,
                stdout=asyncio.subprocess.PIPE,
                stderr=asyncio.subprocess.PIPE,
            )
            out, err = await asyncio.wait_for(proc.communicate(), self.timeout)
        except FileNotFoundError as exc:
            raise DockerError("Docker CLI is not installed") from exc
        except asyncio.TimeoutError as exc:
            raise DockerError("Docker command timed out") from exc
        if proc.returncode and not allow_failure:
            raise DockerError(err.decode(errors="replace").strip() or "Docker command failed")
        return out.decode(errors="replace").strip()

    def validate_name(self, name: str) -> str:
        name = name.lower().strip()
        if not NAME_RE.fullmatch(name):
            raise DockerError("Name must be 3–32 lowercase letters, numbers, or hyphens")
        return name

    def ipv6_for(self, owner_id: int, name: str) -> str:
        digest = hashlib.blake2b(f"{owner_id}:{name}".encode(), digest_size=8).digest()
        host = max(2, int.from_bytes(digest, "big"))
        return str(ipaddress.IPv6Address(int(self.prefix.network_address) + host % (self.prefix.num_addresses - 2)))

    async def ensure_network(self) -> None:
        existing = await self._run("network", "ls", "--filter", f"name=^{self.network}$", "--format", "{{.Name}}")
        if existing == self.network:
            return
        gateway = self.cfg.get("gateway6")
        args = ["network", "create", "--ipv6", "--ipv4=false", "--subnet", str(self.prefix)]
        if gateway:
            args += ["--gateway", gateway]
        args += [self.network]
        await self._run(*args)

    async def state(self, name: str) -> str:
        name = self.validate_name(name)
        result = await self._run("inspect", "--format", "{{.State.Status}}", name, allow_failure=True)
        return result or "not found"

    async def start(self, name: str) -> str:
        return await self._run("start", self.validate_name(name))

    async def stop(self, name: str) -> str:
        return await self._run("stop", "--time", str(int(self.cfg.get("stop_timeout_seconds", 20))), self.validate_name(name))

    async def suspend(self, name: str) -> str:
        return await self._run("pause", self.validate_name(name))

    async def resume(self, name: str) -> str:
        return await self._run("unpause", self.validate_name(name))

    async def delete(self, name: str, preserve_volume: bool = False) -> str:
        name = self.validate_name(name)
        result = await self._run("rm", "--force", name)
        if not preserve_volume:
            await self._run("volume", "rm", f"jvx-{name}-data", allow_failure=True)
        return result

    async def logs(self, name: str, lines: int = 100) -> str:
        return await self._run("logs", "--tail", str(max(1, min(lines, 500))), self.validate_name(name))

    async def stats(self, name: str) -> str:
        return await self._run("stats", "--no-stream", "--format", "{{.CPUPerc}} | {{.MemUsage}} | {{.NetIO}}", self.validate_name(name))

    async def deploy(self, name: str, owner_id: int, vcpus: int, ram_mb: int, disk_gb: int, ssh_key: str) -> str:
        name = self.validate_name(name)
        if not (ssh_key.startswith("ssh-ed25519 ") or ssh_key.startswith("ssh-rsa ") or ssh_key.startswith("ecdsa-sha2-")):
            raise DockerError("A valid OpenSSH public key is required")
        await self.ensure_network()
        ipv6 = self.ipv6_for(owner_id, name)
        image = self.cfg.get("image", "justvihxn/ubuntu-ssh:24.04")
        volume = f"jvx-{name}-data"
        await self._run("volume", "create", volume)
        args = [
            "run", "--detach", "--name", name,
            "--hostname", name,
            "--restart", "unless-stopped",
            "--network", self.network,
            "--ip6", ipv6,
            "--cpus", str(int(vcpus)),
            "--memory", f"{int(ram_mb)}m",
            "--memory-swap", f"{int(ram_mb)}m",
            "--pids-limit", str(int(self.cfg.get("pids_limit", 512))),
            "--cap-drop", "ALL",
            "--cap-add", "CHOWN", "--cap-add", "DAC_OVERRIDE",
            "--cap-add", "FOWNER", "--cap-add", "SETGID",
            "--cap-add", "SETUID", "--cap-add", "NET_BIND_SERVICE",
            "--security-opt", "no-new-privileges:true",
            "--label", "provider=justvihxn",
            "--label", f"owner_id={owner_id}",
            "--label", f"disk_quota_gb={int(disk_gb)}",
            "--env", f"SSH_PUBLIC_KEY={ssh_key.strip()}",
            "--env", f"SSH_USER={self.cfg.get('ssh_user', 'justvihxn')}",
            "--volume", f"{volume}:/home/{self.cfg.get('ssh_user', 'justvihxn')}/data",
            image,
        ]
        try:
            await self._run(*args)
        except Exception:
            await self._run("volume", "rm", volume, allow_failure=True)
            raise
        return ipv6

    async def rebuild(self, name: str, owner_id: int, vcpus: int, ram_mb: int, disk_gb: int, ssh_key: str) -> str:
        name = self.validate_name(name)
        await self.delete(name, preserve_volume=True)
        return await self.deploy(name, owner_id, vcpus, ram_mb, disk_gb, ssh_key)
