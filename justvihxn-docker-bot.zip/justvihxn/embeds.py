from __future__ import annotations
import discord

class BrandEmbeds:
    def __init__(self, brand: dict): self.brand = brand
    def make(self, title: str, description: str = "", *, kind: str = "primary") -> discord.Embed:
        colors = {"primary": self.brand.get("color", 0x22D3EE), "success": self.brand.get("success_color", 0x22C55E), "warning": self.brand.get("warning_color", 0xF59E0B), "error": self.brand.get("error_color", 0xEF4444)}
        icons = {"success": "✅", "warning": "⚠️", "error": "❌", "primary": "🖥️"}
        e = discord.Embed(title=f"{icons[kind]} {title}", description=description, color=colors[kind])
        e.set_footer(text=self.brand.get("footer", "Justvihxn • Docker Cloud"))
        return e
    def error(self, title: str, text: str): return self.make(title, text, kind="error")
    def success(self, title: str, text: str): return self.make(title, text, kind="success")
