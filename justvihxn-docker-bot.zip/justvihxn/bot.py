from __future__ import annotations
import discord
from discord.ext import commands
from .config import load_settings
from .db import Database
from .embeds import BrandEmbeds
from .docker_provider import DockerProvider

class JustvihxnBot(commands.Bot):
    def __init__(self):
        self.settings=load_settings(); intents=discord.Intents.default(); intents.members=True; intents.invites=True
        super().__init__(command_prefix="-", intents=intents)
        self.db=Database(self.settings.database_path); self.provider=DockerProvider(self.settings.docker); self.embeds=BrandEmbeds(self.settings.brand); self.invite_cache={}
    async def setup_hook(self):
        await self.db.init()
        for ext in ("justvihxn.cogs.vps","justvihxn.cogs.admin","justvihxn.cogs.invites","justvihxn.cogs.utility"): await self.load_extension(ext)
        if self.settings.guild_id:
            guild=discord.Object(id=self.settings.guild_id); self.tree.copy_global_to(guild=guild); await self.tree.sync(guild=guild)
        else: await self.tree.sync()
    async def on_ready(self):
        await self.change_presence(activity=discord.Activity(type=discord.ActivityType.watching,name="IPv6 Docker nodes"))
        for g in self.guilds:
            try: self.invite_cache[g.id]={i.code:i.uses or 0 for i in await g.invites()}
            except discord.Forbidden: pass
        print(f"{self.user} online as Justvihxn")
    async def on_app_command_error(self,interaction,error):
        text=getattr(error,"original",error)
        e=self.embeds.error("Command Failed",str(text)[:3500])
        if interaction.response.is_done(): await interaction.followup.send(embed=e,ephemeral=True)
        else: await interaction.response.send_message(embed=e,ephemeral=True)

def run():
    bot=JustvihxnBot(); bot.run(bot.settings.token,log_handler=None)
