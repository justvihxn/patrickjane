from __future__ import annotations
import discord
from discord import app_commands
from discord.ext import commands
from ..checks import bot_admin

class Utility(commands.Cog):
    def __init__(self,bot): self.bot=bot
    @app_commands.command(name="help",description="Show complete Justvihxn usage guidelines")
    async def help_cmd(self,i:discord.Interaction):
        e=self.bot.embeds.make("Justvihxn Docker Cloud","IPv6-only Docker VPS-container management. Public IPv4 is never assigned.")
        e.add_field(name="Provision",value="`/buy` `/deploy` `/listvpses` `/status`",inline=False); e.add_field(name="Lifecycle",value="`/start` `/stop` `/rebuild` `/vps_delete` `/regen_ssh`",inline=False); e.add_field(name="Invites",value="`/invites` `/ticketcheck`",inline=False); e.add_field(name="Renewal",value="`/renew`",inline=False); e.add_field(name="Security",value="SSH keys only. Destructive actions require confirmation. Secrets are never shown in public.",inline=False); await i.response.send_message(embed=e,ephemeral=True)
    @app_commands.command(name="list",description="Review structural cloud configuration")
    @bot_admin()
    async def list_cmd(self,i:discord.Interaction):
        q=self.bot.settings.docker; await i.response.send_message(embed=self.bot.embeds.make("Cloud Configuration",f"Plans: `{', '.join(self.bot.settings.plans)}`\nNetwork: `{q['network']}`\nIPv6 prefix: `{q['ipv6_prefix']}`\nIPv4: `disabled`\nDocker actions: `{'enabled' if q.get('enabled') else 'dry/disabled'}`"),ephemeral=True)
    @app_commands.command(description="Show your message-credit balance")
    async def m(self,i:discord.Interaction):
        await self.bot.db.ensure_user(i.user.id); r=await self.bot.db.fetchone("SELECT credits FROM users WHERE user_id=?",(i.user.id,)); await i.response.send_message(embed=self.bot.embeds.make("Message Credits",f"Balance: **{r['credits']}**"),ephemeral=True)
    @app_commands.command(description="Show a member's message-credit balance")
    @bot_admin()
    async def message(self,i:discord.Interaction,member:discord.Member):
        await self.bot.db.ensure_user(member.id); r=await self.bot.db.fetchone("SELECT credits FROM users WHERE user_id=?",(member.id,)); await i.response.send_message(embed=self.bot.embeds.make("Message Credits",f"{member.mention}: **{r['credits']}**"),ephemeral=True)
    async def credits(self,i,member,delta): await self.bot.db.ensure_user(member.id); await self.bot.db.execute("UPDATE users SET credits=MAX(0,credits+?) WHERE user_id=?",(delta,member.id)); await i.response.send_message(embed=self.bot.embeds.success("Credits Updated",f"{member.mention}: {delta:+d}"),ephemeral=True)
    @app_commands.command(description="Add message credits")
    @bot_admin()
    async def messageadd(self,i:discord.Interaction,member:discord.Member,amount:app_commands.Range[int,1,100000]): await self.credits(i,member,amount)
    @app_commands.command(description="Remove message credits")
    @bot_admin()
    async def messageremove(self,i:discord.Interaction,member:discord.Member,amount:app_commands.Range[int,1,100000]): await self.credits(i,member,-amount)
    @app_commands.command(description="Reset one member's message credits")
    @bot_admin()
    async def messagereset(self,i:discord.Interaction,member:discord.Member): await self.bot.db.ensure_user(member.id); await self.bot.db.execute("UPDATE users SET credits=0 WHERE user_id=?",(member.id,)); await i.response.send_message(embed=self.bot.embeds.success("Credits Reset",member.mention),ephemeral=True)
    @app_commands.command(description="Show current bot latency")
    async def ping(self,i:discord.Interaction): await i.response.send_message(embed=self.bot.embeds.make("Service Status",f"Gateway latency: **{round(self.bot.latency*1000)} ms**\nBrand: **{self.bot.settings.brand['name']}**"),ephemeral=True)

    @app_commands.command(description="Post the VPS claim instructions")
    @bot_admin()
    async def claimmessage(self,i:discord.Interaction):
        e=self.bot.embeds.make("Claim Your Justvihxn VPS","1. Build your valid invite score.\n2. Run `/buy` and choose a plan.\n3. Run `/deploy` with a unique name and SSH public key.\n4. Connect directly over IPv6.\n\nFake invites and leave/rejoin abuse do not count.")
        await i.response.send_message(embed=e)

    @app_commands.command(description="Show the invite renewal reward menu")
    async def renewvps(self,i:discord.Interaction):
        e=self.bot.embeds.make("VPS Renewal Rewards","Ask an administrator for a renewal code after meeting the server requirements, then use `/renew`.")
        for key,p in self.bot.settings.plans.items(): e.add_field(name=p.get("label",key),value=f"`{key}` • {p.get('invites_required',0)} invite points • {p.get('duration_days',30)} days",inline=False)
        await i.response.send_message(embed=e,ephemeral=True)

    @app_commands.command(description="Deploy from an approved support ticket")
    async def ticketdeploy(self,i:discord.Interaction,plan:str,name:str):
        await i.response.send_message(embed=self.bot.embeds.make("Ticket Deployment Ready",f"Plan `{plan}` and name `{name}` recorded. Run `/deploy` with the same values and your SSH public key to complete secure provisioning."),ephemeral=True)

    @app_commands.command(description="Enable or disable invite-based ticket automation")
    @bot_admin()
    async def ticketauto(self,i:discord.Interaction,enabled:bool):
        await self.bot.db.execute("INSERT INTO settings(key,value) VALUES('ticketauto',?) ON CONFLICT(key) DO UPDATE SET value=excluded.value",("true" if enabled else "false",))
        await i.response.send_message(embed=self.bot.embeds.success("Ticket Automation Updated",f"Invite ticket automation is **{'enabled' if enabled else 'disabled'}**."),ephemeral=True)

    @app_commands.command(description="Start a Justvihxn VPS-plan giveaway")
    @bot_admin()
    async def giveaway(self,i:discord.Interaction,plan:str,winners:app_commands.Range[int,1,20]=1):
        if plan not in self.bot.settings.plans:
            return await i.response.send_message(embed=self.bot.embeds.error("Unknown Plan",f"Available: {', '.join(self.bot.settings.plans)}"),ephemeral=True)
        e=self.bot.embeds.make("VPS Plan Giveaway",f"Prize: **{self.bot.settings.plans[plan].get('label',plan)}**\nWinners: **{winners}**\nReact to the message to enter. Staff will close and draw the giveaway.")
        await i.response.send_message(embed=e)
        msg=await i.original_response(); await msg.add_reaction("🎉")

async def setup(bot): await bot.add_cog(Utility(bot))
