from __future__ import annotations
from datetime import datetime,timedelta,timezone
import secrets
import discord
from discord import app_commands
from discord.ext import commands
from ..checks import bot_admin

class Admin(commands.Cog):
    def __init__(self,bot): self.bot=bot
    @app_commands.command(description="Add a Justvihxn bot administrator")
    @bot_admin()
    async def admin_add(self,i:discord.Interaction,member:discord.Member): await self.bot.db.execute("INSERT OR IGNORE INTO admins(user_id) VALUES(?)",(member.id,)); await i.response.send_message(embed=self.bot.embeds.success("Administrator Added",member.mention),ephemeral=True)
    @app_commands.command(description="Remove a Justvihxn bot administrator")
    @bot_admin()
    async def admin_remove(self,i:discord.Interaction,member:discord.Member): await self.bot.db.execute("DELETE FROM admins WHERE user_id=?",(member.id,)); await i.response.send_message(embed=self.bot.embeds.success("Administrator Removed",member.mention),ephemeral=True)
    @app_commands.command(description="List Justvihxn bot administrators")
    @bot_admin()
    async def admin_list(self,i:discord.Interaction):
        rows=await self.bot.db.fetchall("SELECT user_id FROM admins"); txt="\n".join(f"<@{r['user_id']}>" for r in rows) or "No delegated administrators."; await i.response.send_message(embed=self.bot.embeds.make("Administrators",txt),ephemeral=True)
    @app_commands.command(description="Show administrator count and list")
    @bot_admin()
    async def admins(self,i:discord.Interaction): await self.admin_list.callback(self,i)
    @app_commands.command(description="List configured Docker nodes")
    @bot_admin()
    async def nodes(self,i:discord.Interaction):
        q=self.bot.settings.docker; await i.response.send_message(embed=self.bot.embeds.make("Docker Node",f"Network: `{q['network']}`\nIPv6 prefix: `{q['ipv6_prefix']}`\nGateway: `{q['gateway6']}`\nEnabled: `{q.get('enabled',False)}`"),ephemeral=True)
    @app_commands.command(description="Add or update a VPS plan for this runtime")
    @bot_admin()
    async def planadd(self,i:discord.Interaction,key:str,vcpus:app_commands.Range[int,1,32],ram_mb:app_commands.Range[int,256,131072],disk_gb:app_commands.Range[int,5,2048],invites_required:app_commands.Range[int,0,10000]):
        self.bot.settings.plans[key]={"label":key,"vcpus":vcpus,"ram_mb":ram_mb,"disk_gb":disk_gb,"invites_required":invites_required,"duration_days":30}; await i.response.send_message(embed=self.bot.embeds.success("Plan Updated",f"`{key}` is active until restart. Persist it in config.yml."),ephemeral=True)
    @app_commands.command(description="Generate a VPS renewal code")
    @bot_admin()
    async def redeemcreate(self,i:discord.Interaction,days:app_commands.Range[int,1,365],max_uses:app_commands.Range[int,1,100]=1):
        code=f"JVX-{secrets.token_urlsafe(8).upper()}"; await self.bot.db.execute("INSERT INTO redemptions(code,days,max_uses,created_by) VALUES(?,?,?,?)",(code,days,max_uses,i.user.id)); await i.response.send_message(embed=self.bot.embeds.success("Renewal Code Created",f"`{code}` • {days} days • {max_uses} use(s)"),ephemeral=True)
    @app_commands.command(description="Renew a VPS using a redemption code")
    async def renew(self,i:discord.Interaction,name:str,code:str):
        vm=await self.bot.db.find_vm(name)
        if not vm or vm['owner_id']!=i.user.id: return await i.response.send_message(embed=self.bot.embeds.error("Renewal Failed","VPS not found or not owned by you."),ephemeral=True)
        r=await self.bot.db.fetchone("SELECT * FROM redemptions WHERE code=?",(code,))
        if not r or r['uses']>=r['max_uses']: return await i.response.send_message(embed=self.bot.embeds.error("Renewal Failed","Invalid or exhausted code."),ephemeral=True)
        try: base=datetime.fromisoformat(vm['expires_at']) if vm['expires_at'] else datetime.now(timezone.utc)
        except ValueError: base=datetime.now(timezone.utc)
        base=max(base,datetime.now(timezone.utc)); expires=(base+timedelta(days=r['days'])).isoformat()
        await self.bot.db.execute("UPDATE vms SET expires_at=? WHERE name=?",(expires,name)); await self.bot.db.execute("UPDATE redemptions SET uses=uses+1 WHERE code=?",(code,)); await i.response.send_message(embed=self.bot.embeds.success("VPS Renewed",f"`{name}` expires {expires}."),ephemeral=True)
    @app_commands.command(description="Remove all VPS records owned by a user")
    @bot_admin()
    async def usercleanvps(self,i:discord.Interaction,member:discord.Member):
        rows=await self.bot.db.user_vms(member.id)
        for r in rows:
            try: await self.bot.provider.delete(r['name'])
            except Exception: pass
        await self.bot.db.execute("DELETE FROM vms WHERE owner_id=?",(member.id,)); await i.response.send_message(embed=self.bot.embeds.success("User VPS Cleanup",f"Removed {len(rows)} instance(s) for {member.mention}."),ephemeral=True)
    @app_commands.command(description="Remove every tracked VPS record")
    @bot_admin()
    async def clearnode(self,i:discord.Interaction): await i.response.send_message(embed=self.bot.embeds.make("Blocked by Safety Policy","Bulk destructive deletion is not exposed without host-side confirmation. Use `/usercleanvps` or `/vps_delete`.",kind="warning"),ephemeral=True)

    @app_commands.command(description="Create an invite-based VPS renewal reward")
    @bot_admin()
    async def renewadd(self,i:discord.Interaction,days:app_commands.Range[int,1,365],max_uses:app_commands.Range[int,1,100]=1):
        code=f"JVX-{secrets.token_urlsafe(8).upper()}"
        await self.bot.db.execute("INSERT INTO redemptions(code,days,max_uses,created_by) VALUES(?,?,?,?)",(code,days,max_uses,i.user.id))
        await i.response.send_message(embed=self.bot.embeds.success("Renewal Reward Added",f"`{code}` • {days} days • {max_uses} use(s)"),ephemeral=True)

    @app_commands.command(description="Add or update a message-credit plan")
    @bot_admin()
    async def planmessageadd(self,i:discord.Interaction,key:str,credits:app_commands.Range[int,0,100000]):
        await self.bot.db.execute("INSERT INTO settings(key,value) VALUES(?,?) ON CONFLICT(key) DO UPDATE SET value=excluded.value",(f"message_plan:{key}",str(credits)))
        await i.response.send_message(embed=self.bot.embeds.success("Message Plan Updated",f"`{key}` grants **{credits}** credits."),ephemeral=True)

async def setup(bot): await bot.add_cog(Admin(bot))
