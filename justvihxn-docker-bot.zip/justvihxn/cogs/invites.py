from __future__ import annotations
from datetime import datetime,timezone
import discord
from discord import app_commands
from discord.ext import commands
from ..checks import bot_admin

class Invites(commands.Cog):
    def __init__(self,bot): self.bot=bot
    async def log(self,guild,embed):
        cid=self.bot.settings.invites.get("log_channel_id")
        if cid and (ch:=guild.get_channel(int(cid))): await ch.send(embed=embed)
    @commands.Cog.listener()
    async def on_member_join(self,member:discord.Member):
        old=self.bot.invite_cache.get(member.guild.id,{})
        try: current=await member.guild.invites()
        except discord.Forbidden: return
        used=next((x for x in current if (x.uses or 0)>old.get(x.code,0)),None)
        self.bot.invite_cache[member.guild.id]={x.code:x.uses or 0 for x in current}
        inviter=used.inviter.id if used and used.inviter else None
        age=(datetime.now(timezone.utc)-member.created_at).days; fake=age<int(self.bot.settings.invites.get("fake_account_age_days",7))
        prior=await self.bot.db.fetchone("SELECT left_at,inviter_id FROM member_history WHERE guild_id=? AND user_id=?",(member.guild.id,member.id)); rejoin=bool(prior and prior['left_at'])
        await self.bot.db.execute("INSERT INTO member_history(guild_id,user_id,inviter_id,left_at) VALUES(?,?,?,NULL) ON CONFLICT(guild_id,user_id) DO UPDATE SET inviter_id=excluded.inviter_id,joined_at=CURRENT_TIMESTAMP,left_at=NULL",(member.guild.id,member.id,inviter))
        if inviter:
            await self.bot.db.execute("INSERT OR IGNORE INTO invites(guild_id,user_id) VALUES(?,?)",(member.guild.id,inviter))
            col="rejoins" if rejoin else ("fake" if fake else "joins")
            await self.bot.db.execute(f"UPDATE invites SET {col}={col}+1 WHERE guild_id=? AND user_id=?",(member.guild.id,inviter))
        kind="warning" if fake else "success"; title="Fake Invite Flagged" if fake else ("Invite Rejoin Recorded" if rejoin else "Valid Invite Join")
        await self.log(member.guild,self.bot.embeds.make(title,f"{member.mention} joined"+(f" via <@{inviter}>." if inviter else ". No invite identified."),kind=kind))
    @commands.Cog.listener()
    async def on_member_remove(self,member:discord.Member):
        hist=await self.bot.db.fetchone("SELECT inviter_id FROM member_history WHERE guild_id=? AND user_id=?",(member.guild.id,member.id)); await self.bot.db.execute("UPDATE member_history SET left_at=CURRENT_TIMESTAMP WHERE guild_id=? AND user_id=?",(member.guild.id,member.id))
        if hist and hist['inviter_id']:
            await self.bot.db.execute("UPDATE invites SET leaves=leaves+1 WHERE guild_id=? AND user_id=?",(member.guild.id,hist['inviter_id']))
            await self.log(member.guild,self.bot.embeds.make("Invite Leave Recorded",f"{member.mention} left; one invite was removed from <@{hist['inviter_id']}>.",kind="error"))
    @app_commands.command(description="Show a member's invite statistics")
    async def invites(self,i:discord.Interaction,member:discord.Member|None=None):
        m=member or i.user; r=await self.bot.db.fetchone("SELECT * FROM invites WHERE guild_id=? AND user_id=?",(i.guild_id,m.id)); u=await self.bot.db.fetchone("SELECT custom_invites FROM users WHERE user_id=?",(m.id,)); joins=r['joins'] if r else 0; leaves=r['leaves'] if r else 0; fake=r['fake'] if r else 0; rejoins=r['rejoins'] if r else 0; custom=u['custom_invites'] if u else 0; net=joins-leaves-fake+rejoins+custom
        e=self.bot.embeds.make("Server Invite Statistics",f"**{m.display_name}** — Net Invites: **{net}**\n\n📥 **Joins:** {joins}\n📤 **Left:** {leaves}\n⚠️ **Fake:** {fake}\n🔄 **Rejoins:** {rejoins}\n➕ **Custom:** {custom}"); e.set_thumbnail(url=m.display_avatar.url); e.set_footer(text=f"Requested by {i.user.display_name} • {self.bot.settings.brand['footer']}"); await i.response.send_message(embed=e)
    async def adjust(self,i,member,amount):
        await self.bot.db.ensure_user(member.id); await self.bot.db.execute("UPDATE users SET custom_invites=custom_invites+? WHERE user_id=?",(amount,member.id)); await i.response.send_message(embed=self.bot.embeds.success("Invite Score Updated",f"{member.mention}: {amount:+d} custom invite(s)."),ephemeral=True)
    @app_commands.command(description="Add custom invite points")
    @bot_admin()
    async def invitesadd(self,i:discord.Interaction,member:discord.Member,amount:app_commands.Range[int,1,10000]): await self.adjust(i,member,amount)
    @app_commands.command(description="Remove custom invite points")
    @bot_admin()
    async def invitesremove(self,i:discord.Interaction,member:discord.Member,amount:app_commands.Range[int,1,10000]): await self.adjust(i,member,-amount)
    @app_commands.command(description="Reset every member's invite data")
    @bot_admin()
    async def invitereseteveryone(self,i:discord.Interaction): await self.bot.db.execute("DELETE FROM invites WHERE guild_id=?",(i.guild_id,)); await i.response.send_message(embed=self.bot.embeds.success("Invite Data Reset","All invite statistics for this server were reset."),ephemeral=True)
    @app_commands.command(description="Check invite eligibility for VPS deployment")
    async def ticketcheck(self,i:discord.Interaction): await self.invites.callback(self,i,i.user)

async def setup(bot): await bot.add_cog(Invites(bot))
