from __future__ import annotations
from datetime import datetime, timedelta, timezone
import json, secrets
import discord
from discord import app_commands
from discord.ext import commands
from ..checks import bot_admin
from ..docker_provider import DockerError
from ..views import ConfirmView

class VPS(commands.Cog):
    def __init__(self,bot): self.bot=bot
    async def owned(self,user_id,name,admin=False):
        vm=await self.bot.db.find_vm(name)
        if not vm: raise DockerError("VPS not found")
        if vm["owner_id"]!=user_id and not admin: raise DockerError("You do not own this VPS")
        return vm
    async def admin_status(self,uid): return await self.bot.db.is_admin(uid,self.bot.settings.owner_ids)

    @app_commands.command(description="Deploy an IPv6-only Docker VPS container")
    @app_commands.describe(plan="Plan from config.yml",name="Lowercase VPS name",ssh_public_key="Your SSH public key")
    async def deploy(self,i:discord.Interaction,plan:str,name:str,ssh_public_key:str):
        await i.response.defer(ephemeral=True,thinking=True)
        p=self.bot.settings.plans.get(plan)
        if not p: raise DockerError(f"Unknown plan. Available: {', '.join(self.bot.settings.plans)}")
        await self.bot.db.ensure_user(i.user.id)
        count=(await self.bot.db.fetchone("SELECT COUNT(*) n FROM vms WHERE owner_id=?",(i.user.id,)))["n"]
        if count>=int(self.bot.settings.docker.get("max_containers_per_user",3)): raise DockerError("VPS limit reached")
        inv=await self.bot.db.fetchone("SELECT joins-leaves-fake+rejoins+custom_invites score FROM invites LEFT JOIN users USING(user_id) WHERE guild_id=? AND user_id=?",(i.guild_id,i.user.id))
        score=int(inv["score"] or 0) if inv else 0
        if score<int(p.get("invites_required",0)) and not await self.admin_status(i.user.id): raise DockerError(f"This plan requires {p['invites_required']} net invites; you have {score}")
        if await self.bot.db.find_vm(name): raise DockerError("That VPS name already exists")
        ipv6=await self.bot.provider.deploy(name,i.user.id,p["vcpus"],p["ram_mb"],p["disk_gb"],ssh_public_key)
        expires=(datetime.now(timezone.utc)+timedelta(days=int(p.get("duration_days",30)))).isoformat()
        vmid=secrets.token_hex(6)
        await self.bot.db.execute("INSERT INTO vms(id,owner_id,name,plan,ipv6,state,expires_at) VALUES(?,?,?,?,?,'running',?)",(vmid,i.user.id,name,plan,ipv6,expires))
        e=self.bot.embeds.success("VPS Deployment Complete",f"Your **{self.bot.settings.brand['name']}** Docker instance is ready.")
        e.add_field(name="Instance",value=f"`{name}`",inline=True); e.add_field(name="IPv6",value=f"`{ipv6}`",inline=True); e.add_field(name="SSH",value=f"`ssh {self.bot.settings.docker.get('ssh_user','justvihxn')}@{ipv6}`",inline=False); e.add_field(name="Network",value="IPv6 only • No IPv4 assigned",inline=False)
        await i.followup.send(embed=e,ephemeral=True)

    @app_commands.command(description="Power on your VPS")
    async def start(self,i:discord.Interaction,name:str):
        await i.response.defer(ephemeral=True); await self.owned(i.user.id,name,await self.admin_status(i.user.id)); await self.bot.provider.start(name); await self.bot.db.execute("UPDATE vms SET state='running' WHERE name=?",(name,)); await i.followup.send(embed=self.bot.embeds.success("VPS Started",f"`{name}` is running."),ephemeral=True)
    @app_commands.command(description="Safely shut down your VPS")
    async def stop(self,i:discord.Interaction,name:str):
        await i.response.defer(ephemeral=True); await self.owned(i.user.id,name,await self.admin_status(i.user.id)); await self.bot.provider.stop(name); await self.bot.db.execute("UPDATE vms SET state='shutting down' WHERE name=?",(name,)); await i.followup.send(embed=self.bot.embeds.success("Shutdown Requested",f"`{name}` is shutting down."),ephemeral=True)
    @app_commands.command(description="Inspect VPS state and resources")
    async def status(self,i:discord.Interaction,name:str):
        vm=await self.owned(i.user.id,name,await self.admin_status(i.user.id)); state=await self.bot.provider.state(name)
        e=self.bot.embeds.make("VPS Status"); e.add_field(name="Instance",value=f"`{name}`"); e.add_field(name="State",value=f"`{state}`"); e.add_field(name="IPv6",value=f"`{vm['ipv6']}`",inline=False); e.add_field(name="Expires",value=vm["expires_at"] or "Never",inline=False); await i.response.send_message(embed=e,ephemeral=True)
    @app_commands.command(name="vps_delete",description="Permanently destroy your VPS")
    async def vps_delete(self,i:discord.Interaction,name:str):
        await self.owned(i.user.id,name,await self.admin_status(i.user.id)); view=ConfirmView(i.user.id); await i.response.send_message(embed=self.bot.embeds.make("Confirm VPS Deletion",f"Permanently delete `{name}` and its disk?",kind="warning"),view=view,ephemeral=True); await view.wait()
        if not view.value: return await i.edit_original_response(embed=self.bot.embeds.make("Deletion Cancelled"),view=None)
        await self.bot.provider.delete(name); await self.bot.db.execute("DELETE FROM vms WHERE name=?",(name,)); await i.edit_original_response(embed=self.bot.embeds.success("VPS Deleted",f"`{name}` was permanently removed."),view=None)
    @app_commands.command(description="Suspend a running VPS")
    @bot_admin()
    async def suspendvps(self,i:discord.Interaction,name:str): await i.response.defer(ephemeral=True); await self.bot.provider.suspend(name); await self.bot.db.execute("UPDATE vms SET state='suspended' WHERE name=?",(name,)); await i.followup.send(embed=self.bot.embeds.success("VPS Suspended",f"`{name}` is suspended."),ephemeral=True)
    @app_commands.command(description="Resume a suspended VPS")
    @bot_admin()
    async def unsuspendvps(self,i:discord.Interaction,name:str): await i.response.defer(ephemeral=True); await self.bot.provider.resume(name); await self.bot.db.execute("UPDATE vms SET state='running' WHERE name=?",(name,)); await i.followup.send(embed=self.bot.embeds.success("VPS Resumed",f"`{name}` is running."),ephemeral=True)
    @app_commands.command(description="List your VPS instances")
    async def listvpses(self,i:discord.Interaction):
        rows=await self.bot.db.user_vms(i.user.id); text="\n".join(f"`{r['name']}` • {r['plan']} • `{r['ipv6']}` • {r['state']}" for r in rows) or "No VPS instances."; await i.response.send_message(embed=self.bot.embeds.make("Your VPS Instances",text),ephemeral=True)
    @app_commands.command(description="Show the owner of a VPS")
    async def vpscheck_owner(self,i:discord.Interaction,name:str):
        vm=await self.bot.db.find_vm(name)
        if not vm: raise DockerError("VPS not found")
        await i.response.send_message(embed=self.bot.embeds.make("VPS Ownership",f"`{name}` is owned by <@{vm['owner_id']}>."),ephemeral=True)
    @app_commands.command(description="Share VPS visibility with another member")
    async def sharevps(self,i:discord.Interaction,name:str,member:discord.Member):
        vm=await self.owned(i.user.id,name); shared=set(json.loads(vm["shared_with"])); shared.add(member.id); await self.bot.db.execute("UPDATE vms SET shared_with=? WHERE name=?",(json.dumps(list(shared)),name)); await i.response.send_message(embed=self.bot.embeds.success("VPS Shared",f"`{name}` shared with {member.mention}."),ephemeral=True)
    @app_commands.command(description="Rebuild a Docker VPS with a fresh image")
    async def rebuild(self,i:discord.Interaction,name:str,ssh_public_key:str):
        vm=await self.owned(i.user.id,name,await self.admin_status(i.user.id))
        plan=self.bot.settings.plans.get(vm["plan"])
        if not plan: raise DockerError("The VPS plan no longer exists")
        view=ConfirmView(i.user.id)
        await i.response.send_message(embed=self.bot.embeds.make("Confirm Container Rebuild",f"Recreate `{name}` from the current provider image? The persistent data volume will be retained.",kind="warning"),view=view,ephemeral=True)
        await view.wait()
        if not view.value: return await i.edit_original_response(embed=self.bot.embeds.make("Rebuild Cancelled"),view=None)
        ipv6=await self.bot.provider.rebuild(name,i.user.id,plan["vcpus"],plan["ram_mb"],plan["disk_gb"],ssh_public_key)
        await self.bot.db.execute("UPDATE vms SET ipv6=?,state='running' WHERE name=?",(ipv6,name))
        await i.edit_original_response(embed=self.bot.embeds.success("Container Rebuilt",f"`{name}` is running at `{ipv6}`."),view=None)
    @app_commands.command(description="Generate fresh SSH access guidance")
    async def regen_ssh(self,i:discord.Interaction,name:str): await self.owned(i.user.id,name); await i.response.send_message(embed=self.bot.embeds.make("SSH Key Rotation",f"Use your provider console or cloud-init recovery to replace `~/.ssh/authorized_keys` on `{name}`. Passwords are never generated or stored by the bot."),ephemeral=True)
    @app_commands.command(description="Display available IPv6 VPS plans")
    async def buy(self,i:discord.Interaction):
        e=self.bot.embeds.make("VPS Purchase Panel","Choose a plan, then run `/deploy` with your SSH public key. All guests are IPv6-only.")
        for key,p in self.bot.settings.plans.items(): e.add_field(name=p.get("label",key),value=f"`{key}` • {p['vcpus']} vCPU • {p['ram_mb']} MB • {p['disk_gb']} GB • {p.get('invites_required',0)} invites",inline=False)
        await i.response.send_message(embed=e,ephemeral=True)

async def setup(bot): await bot.add_cog(VPS(bot))
