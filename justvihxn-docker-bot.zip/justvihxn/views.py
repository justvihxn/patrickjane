from __future__ import annotations
import discord

class ConfirmView(discord.ui.View):
    def __init__(self, author_id:int): super().__init__(timeout=30); self.author_id=author_id; self.value=None
    async def interaction_check(self,i):
        if i.user.id!=self.author_id: await i.response.send_message("This confirmation is not yours.",ephemeral=True); return False
        return True
    @discord.ui.button(label="Confirm",style=discord.ButtonStyle.danger)
    async def confirm(self,i,button): self.value=True; await i.response.defer(); self.stop()
    @discord.ui.button(label="Cancel",style=discord.ButtonStyle.secondary)
    async def cancel(self,i,button): self.value=False; await i.response.defer(); self.stop()
